module.exports = {
    URL_DB : "mongodb://localhost:27017",
    NAME_DB : "rp-discord",
    VERSION : "Fiche et métier",
    OWNER_ID : "140123457001226241",
    PREFIX : "!"
};
