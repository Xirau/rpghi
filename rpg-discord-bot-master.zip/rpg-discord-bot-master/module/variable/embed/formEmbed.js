module.exports = {
    "author" : {
        "name" : "Numéro de question",
    },
    "color" : "47016",
    "description" : "Question ?",
    "footer" : {
        "text" : "Réaction / Input"
    },
};