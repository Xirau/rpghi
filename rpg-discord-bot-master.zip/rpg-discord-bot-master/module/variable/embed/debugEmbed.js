module.exports = {
    "author" : {
        "name" : "Debug - Information",
    },
    "color" : " 14712576",
    "title" : "Bot Discord RP",
    "footer" : {
        "text" : "Crédit : Faustin#8347"
    },
    "fields" : [
        { //0
            "name" : "Version",
            "value" : "Insérer version",
            "inline" : true
        },
        { //1
            "name" : "Nom du serveur",
            "value" : "Insérer serveur",
            "inline" : true
        },
        { //2
            "name" : "Uptime (os)",
            "value" : "Insérer uptime os",
            "inline" : true
        },
        { //3
            "name" : "Uptime (node)",
            "value" : "Insérer uptime node",
            "inline" : true
        },


    ]
};