module.exports = {
    "author" : {
        "name" : "Gestion des fiches",
    },
    "color" : "1035008",
    "title" : "Listes des fiches de %1",
    "footer" : {
        "text" : "+ d'aide : Faustin#8347"
    },
    "fields" : [
        /*{
            "name" : "id",
            "value" : "(emoji) date",
        },*/
    ]
};