module.exports = {
    "author" : {
        "name" : "Gestion des métiers",
    },
    "color" : "1035008",
    "title" : "Liste des métiers",
    "footer" : {
        "text" : "+ d'aide : Faustin#8347"
    },
    "fields" : [
        /*{
            "name" : "Nom par %1 le %2",
            "value" : "Gain de %1 tous les x ms",
            "inline" : true
        },*/
    ]
};