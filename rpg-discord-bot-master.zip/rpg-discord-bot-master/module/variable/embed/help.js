module.exports = {
    "author" : {
        "name" : "Fiche d'aide du bot : Liste des commandes",
    },
    "color" : "1035008",
    "title" : "Certaines commandes ont des sous-commandes",
    "footer" : {
        "text" : "+ d'aide : Faustin#8347"
    },
    "fields" : [
    ]
};