module.exports = {
    money : ["^ouvre sa bourse$", "^regarde son portefeuille$", "^compte ses sous$", "^regarde ses comptes$", "^regarde son argent$", "^ouvre son portefeuille$"]
};