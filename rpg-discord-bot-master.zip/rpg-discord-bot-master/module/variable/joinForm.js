module.exports = [
    {
        id : "0",
        name : "ready",
        question : "Êtes-vous prêt ?",
        mention : [
            "❌",
            "✅"
        ],

    },
    {
        id : "1",
        name : "ready",
        question : "Toujours prêt ?",
        mention : [
            "❌",
            "✅"
        ],

    }
];